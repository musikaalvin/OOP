package com.smartcampus.repository;

import com.smartcampus.model.Attendance;
import com.smartcampus.model.Course;
import com.smartcampus.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {

    List<Attendance> findByStudent(Student student);

    List<Attendance> findByCourse(Course course);

    List<Attendance> findByCourseAndDate(Course course, LocalDate date);

    List<Attendance> findByStudentAndCourse(Student student, Course course);

    boolean existsByStudentAndCourseAndDate(Student student, Course course, LocalDate date);
}