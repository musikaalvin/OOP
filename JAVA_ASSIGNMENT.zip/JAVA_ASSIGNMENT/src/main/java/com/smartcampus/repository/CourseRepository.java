package com.smartcampus.repository;

import com.smartcampus.model.Course;
import com.smartcampus.model.Lecturer;
import com.smartcampus.model.Program;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CourseRepository extends JpaRepository<Course, Long> {

    Optional<Course> findByCode(String code);

    List<Course> findByProgram(Program program);

    List<Course> findByLecturer(Lecturer lecturer);
}