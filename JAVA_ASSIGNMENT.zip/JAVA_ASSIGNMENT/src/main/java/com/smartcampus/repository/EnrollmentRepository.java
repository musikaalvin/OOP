package com.smartcampus.repository;

import com.smartcampus.model.Course;
import com.smartcampus.model.Enrollment;
import com.smartcampus.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {

    List<Enrollment> findByStudent(Student student);

    List<Enrollment> findByCourse(Course course);

    boolean existsByStudentAndCourse(Student student, Course course);

    Optional<Enrollment> findByStudentAndCourse(Student student, Course course);

    long countByCourse(Course course);
}