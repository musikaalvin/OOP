package com.smartcampus.repository;

import com.smartcampus.model.Student;
import com.smartcampus.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {

    Optional<Student> findByStudentNumber(String studentNumber);

    Optional<Student> findByUser(User user);

    boolean existsByStudentNumber(String studentNumber);
}