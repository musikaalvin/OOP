package com.smartcampus.repository;

import com.smartcampus.model.Course;
import com.smartcampus.model.Result;
import com.smartcampus.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ResultRepository extends JpaRepository<Result, Long> {

    List<Result> findByStudent(Student student);

    List<Result> findByCourse(Course course);

    List<Result> findByStudentAndCourse(Student student, Course course);

    Optional<Result> findFirstByStudentAndCourse(Student student, Course course);
}