package com.smartcampus.repository;

import com.smartcampus.model.Lecturer;
import com.smartcampus.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LecturerRepository extends JpaRepository<Lecturer, Long> {

    Optional<Lecturer> findByStaffNumber(String staffNumber);

    Optional<Lecturer> findByUser(User user);
}