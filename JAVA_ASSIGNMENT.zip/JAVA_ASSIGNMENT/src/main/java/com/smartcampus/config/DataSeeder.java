package com.smartcampus.config;

import com.smartcampus.model.Course;
import com.smartcampus.model.Department;
import com.smartcampus.model.Enrollment;
import com.smartcampus.model.Lecturer;
import com.smartcampus.model.Program;
import com.smartcampus.model.Result;
import com.smartcampus.model.Student;
import com.smartcampus.model.User;
import com.smartcampus.repository.CourseRepository;
import com.smartcampus.repository.DepartmentRepository;
import com.smartcampus.repository.EnrollmentRepository;
import com.smartcampus.repository.LecturerRepository;
import com.smartcampus.repository.ProgramRepository;
import com.smartcampus.repository.ResultRepository;
import com.smartcampus.repository.StudentRepository;
import com.smartcampus.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final ProgramRepository programRepository;
    private final LecturerRepository lecturerRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final ResultRepository resultRepository;

    public DataSeeder(UserRepository userRepository,
                      DepartmentRepository departmentRepository,
                      ProgramRepository programRepository,
                      LecturerRepository lecturerRepository,
                      StudentRepository studentRepository,
                      CourseRepository courseRepository,
                      EnrollmentRepository enrollmentRepository,
                      ResultRepository resultRepository) {
        this.userRepository = userRepository;
        this.departmentRepository = departmentRepository;
        this.programRepository = programRepository;
        this.lecturerRepository = lecturerRepository;
        this.studentRepository = studentRepository;
        this.courseRepository = courseRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.resultRepository = resultRepository;
    }

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) {
            return;
        }

        // ---------- Admin user ----------
        userRepository.save(new User("admin", "admin123", "System Administrator", User.Role.ADMIN));

        // ---------- Departments ----------
        Department it = departmentRepository.save(new Department("IT", "Information Technology"));
        Department bus = departmentRepository.save(new Department("BUS", "Business and Management"));
        Department eng = departmentRepository.save(new Department("ENG", "Engineering"));

        // ---------- Programs ----------
        Program cs = programRepository.save(new Program("CS", "BSc Computer Science", it, 3));
        Program itp = programRepository.save(new Program("IT", "BSc Information Technology", it, 3));
        Program sw = programRepository.save(new Program("SWE", "Bachelor of Software Engineering", it, 4));
        Program dba = programRepository.save(new Program("DBA", "Diploma in Business Administration", bus, 2));
        Program ece = programRepository.save(new Program("ECE", "Diploma in Electronics Engineering", eng, 3));

        // ---------- Lecturers ----------
        Lecturer l1 = saveLecturer("LEC001", "Dr. Sarah", "Namukwaya", "s.namukwaya@example.edu", it);
        Lecturer l2 = saveLecturer("LEC002", "Mr. Daniel", "Okello", "d.okello@example.edu", it);
        Lecturer l3 = saveLecturer("LEC003", "Ms. Grace", "Achieng", "g.achieng@example.edu", bus);
        Lecturer l4 = saveLecturer("LEC004", "Mr. Peter", "Mukasa", "p.mukasa@example.edu", eng);
        Lecturer l5 = saveLecturer("LEC005", "Mrs. Linda", "Kemigisha", "l.kemigisha@example.edu", it);

        // ---------- Students ----------
        Student s1 = saveStudent("STU001", "John", "Kato", "j.kato@example.edu", cs, 1);
        Student s2 = saveStudent("STU002", "Alice", "Nakato", "a.nakato@example.edu", cs, 1);
        Student s3 = saveStudent("STU003", "Brian", "Ochieng", "b.ochieng@example.edu", itp, 2);
        Student s4 = saveStudent("STU004", "Mary", "Ampaire", "m.ampaire@example.edu", dba, 1);
        Student s5 = saveStudent("STU005", "Samuel", "Byaruhanga", "s.byaruhanga@example.edu", sw, 1);
        Student s6 = saveStudent("STU006", "Priscilla", "Nabirye", "p.nabirye@example.edu", itp, 1);

        // ---------- Courses (assigned to lecturers) ----------
        Course java = saveCourse("CSC101", "Introduction to Java Programming", 4, cs, l1, 1, 1);
        Course dbms = saveCourse("CSC102", "Database Systems", 3, cs, l2, 1, 1);
        Course web = saveCourse("IT101", "Web Design and Development", 3, itp, l5, 1, 1);
        Course net = saveCourse("IT102", "Computer Networks", 3, itp, l2, 1, 2);
        Course se = saveCourse("SWE101", "Introduction to Software Engineering", 4, sw, l1, 1, 1);
        Course oop = saveCourse("CSC201", "Object Oriented Programming", 4, cs, l1, 2, 1);
        Course os = saveCourse("CSC202", "Operating Systems", 3, cs, l2, 2, 1);
        Course acc = saveCourse("DBA101", "Principles of Accounting", 3, dba, l3, 1, 1);
        Course sta = saveCourse("DBA102", "Business Statistics", 3, dba, l3, 1, 1);
        Course cir = saveCourse("ECE101", "Electronic Circuits", 3, ece, l4, 1, 1);
        Course dcn = saveCourse("IT201", "Data Communication", 3, itp, l5, 2, 2);

        // ---------- Enrollments ----------
        enroll(s1, java);
        enroll(s1, dbms);
        enroll(s1, oop);
        enroll(s2, java);
        enroll(s2, os);
        enroll(s2, dbms);
        enroll(s3, web);
        enroll(s3, net);
        enroll(s3, dcn);
        enroll(s5, se);
        enroll(s5, oop);
        enroll(s5, java);
        enroll(s6, web);
        enroll(s6, net);

        // ---------- Sample results ----------
        result(s1, java, 35, 45);
        result(s1, dbms, 30, 40);
        result(s1, oop, 40, 50);
        result(s2, java, 45, 50);
        result(s2, os, 25, 30);
        result(s2, dbms, 38, 42);
        result(s3, web, 32, 35);
        result(s3, net, 28, 30);
        result(s5, java, 42, 48);
    }

    private Lecturer saveLecturer(String staffNumber, String first, String last,
                                  String email, Department dept) {
        User user = userRepository.save(new User(staffNumber, "lecturer123",
                first + " " + last, User.Role.LECTURER));
        return lecturerRepository.save(
                new Lecturer(staffNumber, first, last, email, "+256700000001", dept, user));
    }

    private Student saveStudent(String number, String first, String last,
                                String email, Program program, int year) {
        User user = userRepository.save(new User(number, "student123",
                first + " " + last, User.Role.STUDENT));
        return studentRepository.save(new Student(number, first, last, email,
                "+256700000002", program, year, user));
    }

    private Course saveCourse(String code, String name, int units, Program program,
                              Lecturer lecturer, int semester, int year) {
        return courseRepository.save(new Course(code, name, units, program, lecturer, semester, year));
    }

    private void enroll(Student student, Course course) {
        if (!enrollmentRepository.existsByStudentAndCourse(student, course)) {
            enrollmentRepository.save(new Enrollment(student, course, "2025/2026"));
        }
    }

    private void result(Student student, Course course, double cw, double ex) {
        resultRepository.save(new Result(student, course, cw, ex));
    }
}