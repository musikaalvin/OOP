package com.smartcampus.config;

import com.smartcampus.model.User;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        User user = (User) request.getSession().getAttribute("currentUser");
        String path = request.getRequestURI();

        if (user == null) {
            response.sendRedirect("/login");
            return false;
        }

        if (path.startsWith("/admin") && user.getRole() != User.Role.ADMIN) {
            response.sendRedirect("/login");
            return false;
        }
        if (path.startsWith("/lecturer") && user.getRole() != User.Role.LECTURER) {
            response.sendRedirect("/login");
            return false;
        }
        if (path.startsWith("/student") && user.getRole() != User.Role.STUDENT) {
            response.sendRedirect("/login");
            return false;
        }

        return true;
    }
}