package com.smartcampus.controller;

import com.smartcampus.model.Attendance;
import com.smartcampus.model.Course;
import com.smartcampus.model.Enrollment;
import com.smartcampus.model.Lecturer;
import com.smartcampus.model.Result;
import com.smartcampus.model.Student;
import com.smartcampus.model.User;
import com.smartcampus.repository.AttendanceRepository;
import com.smartcampus.repository.CourseRepository;
import com.smartcampus.repository.EnrollmentRepository;
import com.smartcampus.repository.LecturerRepository;
import com.smartcampus.repository.ResultRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/lecturer")
public class LecturerController {

    private final LecturerRepository lecturerRepository;
    private final CourseRepository courseRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final AttendanceRepository attendanceRepository;
    private final ResultRepository resultRepository;

    public LecturerController(LecturerRepository lecturerRepository,
                              CourseRepository courseRepository,
                              EnrollmentRepository enrollmentRepository,
                              AttendanceRepository attendanceRepository,
                              ResultRepository resultRepository) {
        this.lecturerRepository = lecturerRepository;
        this.courseRepository = courseRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.attendanceRepository = attendanceRepository;
        this.resultRepository = resultRepository;
    }

    private Optional<Lecturer> getCurrentLecturer(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        return lecturerRepository.findByUser(user);
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        Lecturer lecturer = getCurrentLecturer(session).orElse(null);
        if (lecturer == null) {
            return "redirect:/login";
        }
        model.addAttribute("lecturer", lecturer);
        model.addAttribute("courses", courseRepository.findByLecturer(lecturer));
        return "lecturer/dashboard";
    }

    @GetMapping("/course/{id}")
    public String courseDetails(@PathVariable Long id, Model model) {
        Course course = courseRepository.findById(id).orElse(null);
        if (course == null) {
            return "redirect:/lecturer/dashboard";
        }
        model.addAttribute("course", course);
        model.addAttribute("enrollments", enrollmentRepository.findByCourse(course));
        model.addAttribute("attendanceDates", attendanceRepository.findByCourse(course).stream()
                .map(Attendance::getDate).distinct().sorted().toList());
        return "lecturer/course";
    }

    // ---------- Attendance ----------

    @GetMapping("/course/{id}/attendance")
    public String attendanceForm(@PathVariable Long id, Model model) {
        Course course = courseRepository.findById(id).orElse(null);
        if (course == null) {
            return "redirect:/lecturer/dashboard";
        }
        model.addAttribute("course", course);
        model.addAttribute("enrollments", enrollmentRepository.findByCourse(course));
        return "lecturer/attendance";
    }

    @PostMapping("/course/{id}/attendance/save")
    public String saveAttendance(@PathVariable Long id,
                                 @RequestParam String date,
                                 @RequestParam(required = false) List<Long> presentStudentIds,
                                 @RequestParam(required = false) List<Long> lateStudentIds,
                                 RedirectAttributes ra) {
        Course course = courseRepository.findById(id).orElse(null);
        if (course == null) {
            return "redirect:/lecturer/dashboard";
        }
        LocalDate dateParsed = LocalDate.parse(date);

        for (Enrollment en : enrollmentRepository.findByCourse(course)) {
            Student student = en.getStudent();
            if (attendanceRepository.existsByStudentAndCourseAndDate(student, course, dateParsed)) {
                continue;
            }
            Attendance.Status status = Attendance.Status.ABSENT;
            if (presentStudentIds != null && presentStudentIds.contains(student.getId())) {
                status = Attendance.Status.PRESENT;
            }
            if (lateStudentIds != null && lateStudentIds.contains(student.getId())) {
                status = Attendance.Status.LATE;
            }
            attendanceRepository.save(new Attendance(student, course, dateParsed, status));
        }
        ra.addFlashAttribute("success", "Attendance recorded for " + dateParsed);
        return "redirect:/lecturer/course/" + id;
    }

    // ---------- Marks ----------

    @GetMapping("/course/{id}/marks")
    public String marksForm(@PathVariable Long id, Model model) {
        Course course = courseRepository.findById(id).orElse(null);
        if (course == null) {
            return "redirect:/lecturer/dashboard";
        }
        model.addAttribute("course", course);
        model.addAttribute("enrollments", enrollmentRepository.findByCourse(course));

        Map<Long, Double> courseworkMap = new HashMap<>();
        Map<Long, Double> examMap = new HashMap<>();
        for (Enrollment en : enrollmentRepository.findByCourse(course)) {
            Optional<Result> r = resultRepository.findFirstByStudentAndCourse(en.getStudent(), course);
            r.ifPresent(result -> {
                courseworkMap.put(en.getStudent().getId(), result.getCourseworkMark());
                examMap.put(en.getStudent().getId(), result.getExamMark());
            });
        }
        model.addAttribute("courseworkMap", courseworkMap);
        model.addAttribute("examMap", examMap);
        return "lecturer/marks";
    }

    @PostMapping("/course/{id}/marks/save")
    public String saveMarks(@PathVariable Long id,
                            @RequestParam(required = false) Map<String, String> allParams,
                            RedirectAttributes ra) {
        Course course = courseRepository.findById(id).orElse(null);
        if (course == null) {
            return "redirect:/lecturer/dashboard";
        }
        for (Enrollment en : enrollmentRepository.findByCourse(course)) {
            Long studentId = en.getStudent().getId();
            String cwKey = "coursework_" + studentId;
            String exKey = "exam_" + studentId;

            String cw = allParams.getOrDefault(cwKey, "");
            String ex = allParams.getOrDefault(exKey, "");
            if (cw.isEmpty() && ex.isEmpty()) {
                continue;
            }
            double cwMark = 0;
            double exMark = 0;
            try {
                cwMark = cw.isEmpty() ? 0 : Double.parseDouble(cw);
                exMark = ex.isEmpty() ? 0 : Double.parseDouble(ex);
            } catch (NumberFormatException e) {
                continue;
            }

            Result result = resultRepository.findFirstByStudentAndCourse(en.getStudent(), course).orElseGet(Result::new);
            result.setStudent(en.getStudent());
            result.setCourse(course);
            result.setCourseworkMark(cwMark);
            result.setExamMark(exMark);
            resultRepository.save(result);
        }
        ra.addFlashAttribute("success", "Marks saved successfully");
        return "redirect:/lecturer/course/" + id;
    }
}