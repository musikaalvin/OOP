package com.smartcampus.controller;

import com.smartcampus.model.Course;
import com.smartcampus.model.Department;
import com.smartcampus.model.Enrollment;
import com.smartcampus.model.Lecturer;
import com.smartcampus.model.Program;
import com.smartcampus.model.Result;
import com.smartcampus.model.Student;
import com.smartcampus.model.User;
import com.smartcampus.repository.CourseRepository;
import com.smartcampus.repository.DepartmentRepository;
import com.smartcampus.repository.EnrollmentRepository;
import com.smartcampus.repository.LecturerRepository;
import com.smartcampus.repository.ProgramRepository;
import com.smartcampus.repository.ResultRepository;
import com.smartcampus.repository.StudentRepository;
import com.smartcampus.repository.UserRepository;
import com.smartcampus.service.ResultService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private final DepartmentRepository departmentRepository;
    private final ProgramRepository programRepository;
    private final StudentRepository studentRepository;
    private final LecturerRepository lecturerRepository;
    private final CourseRepository courseRepository;
    private final UserRepository userRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final ResultRepository resultRepository;
    private final ResultService resultService;

    public AdminController(DepartmentRepository departmentRepository,
                           ProgramRepository programRepository,
                           StudentRepository studentRepository,
                           LecturerRepository lecturerRepository,
                           CourseRepository courseRepository,
                           UserRepository userRepository,
                           EnrollmentRepository enrollmentRepository,
                           ResultRepository resultRepository,
                           ResultService resultService) {
        this.departmentRepository = departmentRepository;
        this.programRepository = programRepository;
        this.studentRepository = studentRepository;
        this.lecturerRepository = lecturerRepository;
        this.courseRepository = courseRepository;
        this.userRepository = userRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.resultRepository = resultRepository;
        this.resultService = resultService;
    }

    // ---------- Dashboard ----------

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("studentCount", studentRepository.count());
        model.addAttribute("lecturerCount", lecturerRepository.count());
        model.addAttribute("courseCount", courseRepository.count());
        model.addAttribute("programCount", programRepository.count());
        model.addAttribute("departmentCount", departmentRepository.count());
        return "admin/dashboard";
    }

    // ---------- Departments ----------

    @GetMapping("/departments")
    public String departments(Model model) {
        model.addAttribute("departments", departmentRepository.findAll());
        model.addAttribute("department", new Department());
        return "admin/departments";
    }

    @PostMapping("/departments/save")
    public String saveDepartment(@ModelAttribute Department department,
                                 RedirectAttributes ra) {
        departmentRepository.save(department);
        ra.addFlashAttribute("success", "Department saved successfully");
        return "redirect:/admin/departments";
    }

    @GetMapping("/departments/delete/{id}")
    public String deleteDepartment(@PathVariable Long id, RedirectAttributes ra) {
        departmentRepository.deleteById(id);
        ra.addFlashAttribute("success", "Department deleted");
        return "redirect:/admin/departments";
    }

    // ---------- Programs ----------

    @GetMapping("/programs")
    public String programs(Model model) {
        model.addAttribute("programs", programRepository.findAll());
        model.addAttribute("departments", departmentRepository.findAll());
        return "admin/programs";
    }

    @PostMapping("/programs/save")
    public String saveProgram(@ModelAttribute Program program,
                              @RequestParam Long departmentId,
                              RedirectAttributes ra) {
        departmentRepository.findById(departmentId).ifPresent(program::setDepartment);
        programRepository.save(program);
        ra.addFlashAttribute("success", "Program saved successfully");
        return "redirect:/admin/programs";
    }

    @GetMapping("/programs/delete/{id}")
    public String deleteProgram(@PathVariable Long id, RedirectAttributes ra) {
        programRepository.deleteById(id);
        ra.addFlashAttribute("success", "Program deleted");
        return "redirect:/admin/programs";
    }

    // ---------- Students ----------

    @GetMapping("/students")
    public String students(Model model) {
        model.addAttribute("students", studentRepository.findAll());
        model.addAttribute("programs", programRepository.findAll());
        model.addAttribute("newStudent", new Student());
        return "admin/students";
    }

    @PostMapping("/students/save")
    public String saveStudent(@ModelAttribute Student student,
                              @RequestParam Long programId,
                              RedirectAttributes ra) {
        programRepository.findById(programId).ifPresent(student::setProgram);
        String studentNumber = student.getStudentNumber();
        if (!userRepository.existsByUsername(studentNumber)) {
            User user = new User(studentNumber, studentNumber,
                    student.getFirstName() + " " + student.getLastName(), User.Role.STUDENT);
            userRepository.save(user);
            student.setUser(user);
        } else {
            student.setUser(userRepository.findByUsername(studentNumber).orElse(null));
        }
        studentRepository.save(student);
        ra.addFlashAttribute("success", "Student saved successfully");
        return "redirect:/admin/students";
    }

    @GetMapping("/students/delete/{id}")
    public String deleteStudent(@PathVariable Long id, RedirectAttributes ra) {
        studentRepository.findById(id).ifPresent(s -> {
            if (s.getUser() != null) {
                userRepository.delete(s.getUser());
            }
            studentRepository.delete(s);
        });
        ra.addFlashAttribute("success", "Student deleted");
        return "redirect:/admin/students";
    }

    // ---------- Lecturers ----------

    @GetMapping("/lecturers")
    public String lecturers(Model model) {
        model.addAttribute("lecturers", lecturerRepository.findAll());
        model.addAttribute("departments", departmentRepository.findAll());
        model.addAttribute("newLecturer", new Lecturer());
        return "admin/lecturers";
    }

    @PostMapping("/lecturers/save")
    public String saveLecturer(@ModelAttribute Lecturer lecturer,
                               @RequestParam Long departmentId,
                               RedirectAttributes ra) {
        departmentRepository.findById(departmentId).ifPresent(lecturer::setDepartment);
        String staffNumber = lecturer.getStaffNumber();
        if (!userRepository.existsByUsername(staffNumber)) {
            User user = new User(staffNumber, staffNumber,
                    lecturer.getFirstName() + " " + lecturer.getLastName(), User.Role.LECTURER);
            userRepository.save(user);
            lecturer.setUser(user);
        } else {
            lecturer.setUser(userRepository.findByUsername(staffNumber).orElse(null));
        }
        lecturerRepository.save(lecturer);
        ra.addFlashAttribute("success", "Lecturer saved successfully");
        return "redirect:/admin/lecturers";
    }

    @GetMapping("/lecturers/delete/{id}")
    public String deleteLecturer(@PathVariable Long id, RedirectAttributes ra) {
        lecturerRepository.findById(id).ifPresent(l -> {
            if (l.getUser() != null) {
                userRepository.delete(l.getUser());
            }
            lecturerRepository.delete(l);
        });
        ra.addFlashAttribute("success", "Lecturer deleted");
        return "redirect:/admin/lecturers";
    }

    // ---------- Courses ----------

    @GetMapping("/courses")
    public String courses(Model model) {
        model.addAttribute("courses", courseRepository.findAll());
        model.addAttribute("programs", programRepository.findAll());
        model.addAttribute("lecturers", lecturerRepository.findAll());
        model.addAttribute("newCourse", new Course());
        return "admin/courses";
    }

    @PostMapping("/courses/save")
    public String saveCourse(@ModelAttribute Course course,
                             @RequestParam Long programId,
                             @RequestParam(required = false) Long lecturerId,
                             RedirectAttributes ra) {
        programRepository.findById(programId).ifPresent(course::setProgram);
        if (lecturerId != null) {
            lecturerRepository.findById(lecturerId).ifPresent(course::setLecturer);
        }
        courseRepository.save(course);
        ra.addFlashAttribute("success", "Course saved successfully");
        return "redirect:/admin/courses";
    }

    @GetMapping("/courses/delete/{id}")
    public String deleteCourse(@PathVariable Long id, RedirectAttributes ra) {
        courseRepository.deleteById(id);
        ra.addFlashAttribute("success", "Course deleted");
        return "redirect:/admin/courses";
    }

    // ---------- Reports ----------

    @GetMapping("/reports")
    public String reports(Model model) {
        model.addAttribute("students", studentRepository.findAll());
        return "admin/reports";
    }

    @GetMapping("/reports/student/{id}")
    public String studentReport(@PathVariable Long id, Model model) {
        Student student = studentRepository.findById(id).orElse(null);
        if (student == null) {
            return "redirect:/admin/reports";
        }
        model.addAttribute("student", student);
        model.addAttribute("results", resultRepository.findByStudent(student));
        model.addAttribute("enrollments", enrollmentRepository.findByStudent(student));
        model.addAttribute("gpa", resultService.calculateGPA(resultRepository.findByStudent(student)));
        model.addAttribute("classification", resultService.classifyGPA(
                resultService.calculateGPA(resultRepository.findByStudent(student))));
        return "admin/student-report";
    }

    // ---------- Course statistics ----------

    @GetMapping("/courses/stats/{id}")
    public String courseStats(@PathVariable Long id, Model model) {
        Course course = courseRepository.findById(id).orElse(null);
        if (course == null) {
            return "redirect:/admin/courses";
        }
        model.addAttribute("course", course);
        model.addAttribute("students", enrollmentRepository.findByCourse(course));
        model.addAttribute("studentCount", enrollmentRepository.countByCourse(course));
        return "admin/course-stats";
    }
}