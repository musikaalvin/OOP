package com.smartcampus.controller;

import com.smartcampus.model.Attendance;
import com.smartcampus.model.Course;
import com.smartcampus.model.Enrollment;
import com.smartcampus.model.Result;
import com.smartcampus.model.Student;
import com.smartcampus.model.User;
import com.smartcampus.repository.AttendanceRepository;
import com.smartcampus.repository.CourseRepository;
import com.smartcampus.repository.EnrollmentRepository;
import com.smartcampus.repository.ResultRepository;
import com.smartcampus.repository.StudentRepository;
import com.smartcampus.service.ResultService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/student")
public class StudentController {

    private final StudentRepository studentRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final CourseRepository courseRepository;
    private final AttendanceRepository attendanceRepository;
    private final ResultRepository resultRepository;
    private final ResultService resultService;

    public StudentController(StudentRepository studentRepository,
                             EnrollmentRepository enrollmentRepository,
                             CourseRepository courseRepository,
                             AttendanceRepository attendanceRepository,
                             ResultRepository resultRepository,
                             ResultService resultService) {
        this.studentRepository = studentRepository;
        this.enrollmentRepository = enrollmentRepository;
        this.courseRepository = courseRepository;
        this.attendanceRepository = attendanceRepository;
        this.resultRepository = resultRepository;
        this.resultService = resultService;
    }

    private Student getCurrentStudent(HttpSession session) {
        User user = (User) session.getAttribute("currentUser");
        return studentRepository.findByUser(user).orElse(null);
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        Student student = getCurrentStudent(session);
        if (student == null) {
            return "redirect:/login";
        }
        model.addAttribute("student", student);
        session.setAttribute("studentInfo", student);
        model.addAttribute("enrollments", enrollmentRepository.findByStudent(student));
        List<Result> results = resultRepository.findByStudent(student);
        model.addAttribute("results", results);
        model.addAttribute("gpa", resultService.calculateGPA(results));
        model.addAttribute("classification", resultService.classifyGPA(resultService.calculateGPA(results)));
        return "student/dashboard";
    }

    @GetMapping("/profile")
    public String profile(HttpSession session, Model model) {
        Student student = getCurrentStudent(session);
        if (student == null) {
            return "redirect:/login";
        }
        model.addAttribute("student", student);
        return "student/profile";
    }

    // ---------- Course Registration ----------

    @GetMapping("/registration")
    public String registration(HttpSession session, Model model) {
        Student student = getCurrentStudent(session);
        if (student == null) {
            return "redirect:/login";
        }
        List<Course> allCourses = courseRepository.findByProgram(student.getProgram());
        Set<Long> enrolledCourseIds = enrollmentRepository.findByStudent(student).stream()
                .map(e -> e.getCourse().getId())
                .collect(Collectors.toSet());

        model.addAttribute("student", student);
        model.addAttribute("availableCourses", allCourses);
        model.addAttribute("enrolledCourseIds", enrolledCourseIds);
        return "student/registration";
    }

    @PostMapping("/register")
    public String registerCourse(@RequestParam Long courseId,
                                 HttpSession session,
                                 RedirectAttributes ra) {
        Student student = getCurrentStudent(session);
        if (student == null) {
            return "redirect:/login";
        }
        Course course = courseRepository.findById(courseId).orElse(null);
        if (course == null) {
            return "redirect:/student/registration";
        }
        if (!enrollmentRepository.existsByStudentAndCourse(student, course)) {
            enrollmentRepository.save(new Enrollment(student, course, "2025/2026"));
            ra.addFlashAttribute("success", "Registered for " + course.getName());
        } else {
            ra.addFlashAttribute("error", "Already registered for " + course.getName());
        }
        return "redirect:/student/registration";
    }

    @GetMapping("/enrollments")
    public String myCourses(HttpSession session, Model model) {
        Student student = getCurrentStudent(session);
        if (student == null) {
            return "redirect:/login";
        }
        model.addAttribute("student", student);
        model.addAttribute("enrollments", enrollmentRepository.findByStudent(student));
        return "student/enrollments";
    }

    // ---------- Attendance ----------

    @GetMapping("/attendance")
    public String attendance(HttpSession session, Model model) {
        Student student = getCurrentStudent(session);
        if (student == null) {
            return "redirect:/login";
        }
        List<Attendance> records = attendanceRepository.findByStudent(student);
        model.addAttribute("student", student);
        model.addAttribute("records", records);
        long total = records.size();
        long present = records.stream().filter(a -> a.getStatus() == Attendance.Status.PRESENT).count();
        long late = records.stream().filter(a -> a.getStatus() == Attendance.Status.LATE).count();
        long absent = records.stream().filter(a -> a.getStatus() == Attendance.Status.ABSENT).count();
        model.addAttribute("total", total);
        model.addAttribute("present", present);
        model.addAttribute("late", late);
        model.addAttribute("absent", absent);
        return "student/attendance";
    }

    // ---------- Results / Transcript ----------

    @GetMapping("/results")
    public String results(HttpSession session, Model model) {
        Student student = getCurrentStudent(session);
        if (student == null) {
            return "redirect:/login";
        }
        List<Result> results = resultRepository.findByStudent(student);
        model.addAttribute("student", student);
        model.addAttribute("results", results);
        model.addAttribute("gpa", resultService.calculateGPA(results));
        model.addAttribute("classification", resultService.classifyGPA(resultService.calculateGPA(results)));
        return "student/results";
    }

    @GetMapping("/transcript")
    public String transcript(HttpSession session, Model model) {
        Student student = getCurrentStudent(session);
        if (student == null) {
            return "redirect:/login";
        }
        List<Result> results = resultRepository.findByStudent(student);
        model.addAttribute("student", student);
        model.addAttribute("results", results);
        model.addAttribute("gpa", resultService.calculateGPA(results));
        model.addAttribute("classification", resultService.classifyGPA(resultService.calculateGPA(results)));
        return "student/transcript";
    }
}