package com.smartcampus.controller;

import com.smartcampus.model.Student;
import com.smartcampus.model.User;
import com.smartcampus.repository.StudentRepository;
import com.smartcampus.service.AuthService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    private final AuthService authService;
    private final StudentRepository studentRepository;

    public AuthController(AuthService authService, StudentRepository studentRepository) {
        this.authService = authService;
        this.studentRepository = studentRepository;
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "auth/login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        HttpSession session,
                        Model model) {
        User user = authService.authenticate(username, password);
        if (user == null) {
            model.addAttribute("error", "Invalid username or password");
            return "auth/login";
        }

        session.setAttribute("currentUser", user);

        if (user.getRole() == User.Role.STUDENT) {
            studentRepository.findByUser(user).ifPresent(s -> session.setAttribute("studentInfo", s));
            return "redirect:/student/dashboard";
        } else if (user.getRole() == User.Role.LECTURER) {
            return "redirect:/lecturer/dashboard";
        } else {
            return "redirect:/admin/dashboard";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}