package com.smartcampus.service;

import com.smartcampus.model.Result;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

@Service
public class ResultService {

    public double calculateGPA(List<Result> results) {
        if (results == null || results.isEmpty()) {
            return 0.0;
        }
        double totalPoints = 0;
        int totalUnits = 0;
        for (Result r : results) {
            totalPoints += r.getGradePoint() * r.getCourse().getCreditUnits();
            totalUnits += r.getCourse().getCreditUnits();
        }
        if (totalUnits == 0) {
            return 0.0;
        }
        return Math.round((totalPoints / totalUnits) * 100.0) / 100.0;
    }

    public String classifyGPA(double gpa) {
        if (gpa >= 4.5) {
            return "Distinction";
        } else if (gpa >= 3.6) {
            return "Credit";
        } else if (gpa >= 2.0) {
            return "Pass";
        } else {
            return "Fail";
        }
    }
}