package com.smartcampus.model;

import jakarta.persistence.*;

@Entity
@Table(name = "results")
public class Result {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    private double courseworkMark;

    private double examMark;

    public Result() {
    }

    public Result(Student student, Course course, double courseworkMark, double examMark) {
        this.student = student;
        this.course = course;
        this.courseworkMark = courseworkMark;
        this.examMark = examMark;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public double getCourseworkMark() {
        return courseworkMark;
    }

    public void setCourseworkMark(double courseworkMark) {
        this.courseworkMark = courseworkMark;
    }

    public double getExamMark() {
        return examMark;
    }

    public void setExamMark(double examMark) {
        this.examMark = examMark;
    }

    public double getTotalMark() {
        return courseworkMark + examMark;
    }

    public String getGrade() {
        double total = getTotalMark();
        if (total >= 80) {
            return "A";
        } else if (total >= 70) {
            return "B+";
        } else if (total >= 60) {
            return "B";
        } else if (total >= 50) {
            return "C";
        } else if (total >= 40) {
            return "D";
        } else {
            return "F";
        }
    }

    public double getGradePoint() {
        double total = getTotalMark();
        if (total >= 80) {
            return 5.0;
        } else if (total >= 70) {
            return 4.5;
        } else if (total >= 60) {
            return 4.0;
        } else if (total >= 50) {
            return 3.0;
        } else if (total >= 40) {
            return 2.0;
        } else {
            return 0.0;
        }
    }

    public String getPassed() {
        return getTotalMark() >= 50 ? "Y" : "N";
    }
}